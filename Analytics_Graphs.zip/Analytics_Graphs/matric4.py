import gspread
import pandas as pd
import matplotlib.pyplot as plt

gc = gspread.service_account(filename='credentials.json')
spreadsheet = gc.open("My526_statistic_v1")
worksheet = spreadsheet.sheet1

data = worksheet.get_all_values()
df = pd.DataFrame(data[1:], columns=data[0])

df['Level Completion'] = pd.to_numeric(df['Level Completion'], errors='coerce')
df['Level'] = df['Level'].astype(str)

completion_counts = df.groupby('Level')['Level Completion'].value_counts().unstack(fill_value=0)
completion_counts.columns = ['Failed', 'Passed']  
completion_counts = completion_counts.reset_index()

completion_counts['Total'] = completion_counts['Failed'] + completion_counts['Passed']
completion_counts['Completion Rate (%)'] = (completion_counts['Passed'] / completion_counts['Total']) * 100
completion_counts['Failure Rate (%)'] = (completion_counts['Failed'] / completion_counts['Total']) * 100

print(completion_counts)


levels = completion_counts['Level']
completion_rates = completion_counts['Completion Rate (%)']
failure_rates = completion_counts['Failure Rate (%)']

plt.figure(figsize=(10, 6))
plt.bar(levels, completion_rates, label="Completed", color="lightgreen", edgecolor="black")
plt.bar(levels, failure_rates, bottom=completion_rates, label="Not Completed", color="salmon", edgecolor="black")


plt.title("Player Completion Rate per Level", fontsize=16)
plt.xlabel("Level", fontsize=14)
plt.ylabel("Completion Rate (%)", fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)


plt.ylim(0, 110)

for i in range(len(levels)):
    plt.text(i, completion_rates[i] / 2, f"{completion_rates[i]:.1f}%", ha='center', va='center', fontsize=10, color='black')
    plt.text(i, completion_rates[i] + failure_rates[i] / 2, f"{failure_rates[i]:.1f}%", ha='center', va='center', fontsize=10, color='black')

plt.legend(fontsize=12)

plt.tight_layout()
plt.show()

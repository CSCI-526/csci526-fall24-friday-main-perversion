import gspread
import pandas as pd
import matplotlib.pyplot as plt

gc = gspread.service_account(filename='credentials.json')
spreadsheet = gc.open("My526_statistic_v1")
worksheet = spreadsheet.sheet1

data = worksheet.get_all_values()
df = pd.DataFrame(data[1:], columns=data[0])

df['Time Spent'] = pd.to_numeric(df['Time Spent'], errors='coerce')
df['Level'] = df['Level'].astype(str)

time_spent_means = df.groupby('Level')['Time Spent'].mean().reset_index()
time_spent_means.columns = ['Level', 'Time Spent Mean']

print(time_spent_means)

plt.figure(figsize=(10, 6))
plt.bar(time_spent_means['Level'], time_spent_means['Time Spent Mean'], color="skyblue", edgecolor="black")

plt.title("Average Time Spent per Level", fontsize=16)
plt.xlabel("Level", fontsize=14)
plt.ylabel("Average Time Spent", fontsize=14)
plt.xticks(rotation=0, fontsize=12)
plt.yticks(fontsize=12)

for i, v in enumerate(time_spent_means['Time Spent Mean']):
    plt.text(i, v + 2, f"{v:.3f}", ha='center', va='bottom', fontsize=10)

plt.tight_layout()
plt.show()


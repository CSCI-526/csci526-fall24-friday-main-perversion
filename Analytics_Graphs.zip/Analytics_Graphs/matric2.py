import gspread
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import pandas as pd
import matplotlib.pyplot as plt

gc = gspread.service_account(filename='credentials.json')
spreadsheet = gc.open("My526_statistic_v1")
worksheet = spreadsheet.sheet1

data = worksheet.get_all_values()
df = pd.DataFrame(data[1:], columns=data[0])

df['Time Spent'] = pd.to_numeric(df['Time Spent'], errors='coerce')
df['Rotation Count'] = pd.to_numeric(df['Rotation Count'], errors='coerce')
df['Respawn Count'] = pd.to_numeric(df['Respawn Count'], errors='coerce')
df['Level Completion'] = pd.to_numeric(df['Level Completion'], errors='coerce')  # 新增

grouped = df.groupby('Level').agg({
    'Time Spent': 'mean',  
    'Rotation Count': 'mean',  
    'Respawn Count': ['mean', 'max', 'min'],  
    'Level Completion': 'mean'  
}).reset_index()

grouped.columns = ['Level', 
                   'Time Spent Mean', 
                   'Rotation Count Mean', 
                   'Respawn Count Mean', 
                   'Respawn Count Max', 
                   'Respawn Count Min', 
                   'Level Completion Rate']

print(grouped)

plt.figure(figsize=(12, 6))
x = grouped['Level']
plt.bar(x, grouped['Respawn Count Mean'], label='Mean', color='skyblue', edgecolor='black', alpha=0.7)
plt.scatter(x, grouped['Respawn Count Max'], label='Max', color='red', marker='o', s=100)
plt.scatter(x, grouped['Respawn Count Min'], label='Min', color='green', marker='x', s=100)

plt.title("Respawn Count Statistics per Level", fontsize=16)
plt.xlabel("Level", fontsize=14)
plt.ylabel("Respawn Count", fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.legend(fontsize=12)
plt.tight_layout()
plt.show()